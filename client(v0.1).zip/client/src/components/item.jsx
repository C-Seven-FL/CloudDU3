/*
import React, { Component } from 'react'

export class Item extends Component {
    render() {
        return(
            <div className='item'>
                <h2>{this.props.item.name}</h2>
                <p>{new Date(this.props.item.date).toLocaleDateString()}</p>
                <b>{this.props.item.notes || "—"}</b>
                <div className='add-to-wrecord'>+</div>
            </div>
        )
    }
}

export default Item
*/