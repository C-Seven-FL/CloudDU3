import React from 'react';

function RecordList() {
  return (
    <div>
      <h2>TEST</h2>
    </div>
  );
}

export default RecordList;